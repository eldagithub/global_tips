 
debug()
{
if [ "$DEBUG" = "Y" ]
  then
    echo "$*"
  fi
}

addParam()
{
  p="$1"
  v="$2"
  P=`echo $p | tr '[a-z]' '[A-Z]'`
  paramCount=`expr $paramCount + 1`
  if [ "$P" = "DESFORMAT" ]
  then
    #
    #     If DESFORMAT is a .prt file, we must convert the 
    # first part of the name to uppercase and add '.prt' in lowercase
    #
    f=`basename $v .prt`
    if [ "$f" != "$v" ]
    then
      v=`echo $f | tr '[a-z]' '[A-Z]'`.prt
    fi
  fi
  
  if [ "$P" = "REPORT" -o "$P" = "MODULE" -o \( $paramCount -eq 1 -a "$p" = "$v" \) ]
  then
    #
    #     Strip PATH and extension from report NAME (if no parameter name
    #  specified and this parameter is the FIRST ONE, we assume that
    #  this is the MODULE NAME
    #
    #     Module name is the only parameter that can be positional
    #
    p="MODULE"
    v=`echo $v | sed -e "s;^ *;;" -e "s; *$;;"`
    v=`basename $v .rep`
    v=`basename $v .rdf`
    v=`basename $v .REP`
    v=`basename $v .RDF`
  fi

  if [ "$P" = "DESNAME" ]
  then
    #
    #    Store the initial DESNAME (destination file for
    # future use
    #
    theFile=$v
    debug "        - File : [$theFile]"
  else
    #
    #     Just add the parameter on the new command-line and 
    # quote the value.
    #
    debug "        - Name : [$p]"
    debug "        - Value: [$v]"
    if [ "$v" != "$p" ]
    then
      pList="$pList $p="
    fi
    if [ "$v" != "" ]
    then
      pList="$pList${theQuote}$v${theQuote}"
    fi
  fi
}


########################################################################################

debug=""

if [ "`uname`" = "SunOs" ]
then
  SSH=/usr/local/bin/ssh 
  SSH_OPT="-F $HOME/ssh_config -o StrictHostKeyChecking=no"
else
  SSH=ssh
  SSH_OPT="-o StrictHostKeyChecking=no"
fi
#      Predefined environments. -type allow the specification of an
# environment type (EXP/HOM/APP/DEV) which correspond to env name, server
# and user
if [ "$1" = "-type" ]
then
  echo
  echo "  Environment TYPE:"
  case $2 in
    TPE|TVA)
      theApp=$2
      ;;
    *)
      echo "Unknown application TRIGRAM: $2"
      exit 1
      ;;
  esac
  echo "    Application : $theApp"  
  theType=$3
  theBase=$4
  case $3 in
    EXP)
      theEnv=${theApp}_PRD 
      theServer=sage.fr.world.socgen 
      theUser=ttgprd01
      ;;
    HOM |DEV )
      
      theEnv=${theApp}${theBase}
      echo $theEnv test12
      theServer=revel.fr.world.socgen 
      theUser=ttgdev01
      ;;
    *)
      echo "Unknown environment type : $3"
      exit 1
      ;;
  esac
  echo "    Type        : $3"  
  echo "    Env         : $theEnv"  
  echo "    Server      : $theServer"  
  echo "    User        : $theUser"  
  echo ""
  
  shift ; shift ; shift ; shift ;
fi 
#      Name of the environment to use on the destination machine 
#      Eg: TPE_DEVUNIX, TVA_DEVUNIX ... TPE_PRD, TVA_PRD, GAT_PRD
if [ "$1" = "-env" ]
then
  theEnv=$2
  shift ; shift
else
  theEnv=${theEnv:-TPED14}
fi
#     Application server name (Can be a load balancer, we will
# get the real server name as first call)
if [ "$1" = "-server" ]
then
  theServer=$2
  shift ; shift
else
  theServer=${theServer:-revel.fr.world.socgen}
fi
#
#     Name of the users to use for ssh and scp commands
#     Those users must "trust" the originating server/user
if [ "$1" = "-user" ]
then
  theUser=$2
  shift ; shift
else
  theUser=${theUser:-ttgdev01}
fi


if [ "$1" = "-debug" ]
then
  #
  #   ACtivate the debug mode and shifts the parameters left
  #
  DEBUG="Y"
  debug="-debug"
  shift
fi
if [ "$1" = "-t" ]
then
  #
  #    Run a test command
  #
  runReportBatch_dev.sh -type TPE ${theType:-DEV} $debug module="   tpeestk   " destype=file desname=./theFile.pdf desformat=PDF userid=TPECHOLLET/SAGE1234@opartpeh01 P_CODTRSNTT="256" P_CODTRSCLI="1173" P_DATCLC="20060623" P_TYPCODTIT="MN" P_TYPCODTIT1="MN" P_TYPCODTIT2="IS" P_TYPCODTIT3="QU" P_INIOPE="CHOLL" P_DECGMTSRV="2" P_DECGMTCLI="2" P_indincexc="I" P_CODDMN="ALLPEAV"
  exit $?
fi

if [ "$1" = "-t1" ]
then
  #
  #    Run a test command (module name withour module=)
  #
  runReportBatch_dev.sh -env $theEnv -server $theServer -user $theUser $debug tpeestk destype=file desname=./theFile.pdf desformat=PDF userid=$STD_ORA_CONNEXION P_CODTRSNTT="256" P_CODTRSCLI="1173" P_DATCLC="20060623" P_TYPCODTIT="MN" P_TYPCODTIT1="MN" P_TYPCODTIT2="IS" P_TYPCODTIT3="QU" P_INIOPE="CHOLL" P_DECGMTSRV="2" P_DECGMTCLI="2" P_indincexc="I" P_CODDMN="ALLPEAV"
  exit $?
fi

if [ "$1" = "-t2" ]
then
  #
  #    Run a test command (we generate a command file and 
  # run a report using this command file).
  #
  echo "\
module=tpefoste
#userid=/
orientation=LANDSCAPE
destype=file
batch=YES
desformat=tpe23066.prt
mode=CHARACTER
p_codtrsntt=256
p_libcrtntt=SOCIETE_GENERALE
p_codmnentt=SG
p_codcattit=A
p_coddmn=OTA
p_ca3isodevset=
p_decgmtcli=2
p_decgmtsrv=2
p_iniope=TPE
p_codtit=

desname=tpefoste_1j.lis
p_datdeb=25MAY2006
p_datfin=24JUN2006" > cmdFile.cmd

if [ "$USERID" = "" ]
then
  USERID=$ORA_CONNEXION
fi
  runReportBatch_dev.sh -env $theEnv -server $theServer -user $theUser -debug userid=$USERID cmdfile=`pwd`/cmdFile.cmd
  rm -f cmdFile.cmd
  exit $?
fi

if [ "$1" = "-t3" ]
then
  #
  #    Run a test command
  #
  export codgop='C'
  export ficftp=/tmp/theFile.tmp
  runReportBatch_dev.sh -debug tvafrapm.rep \
          userid=$USERID \
          batch=yes \
          desformat="$TVA_FIC/tpefile.prt" \
          desname="$ficftp" \
          destype=file \
          mode=character \
          p_where=" and t1.codgop='$codgop' order by t1.codgop asc, t1.codmne asc, t1.typost asc, t1.ca3isodev asc, t1.typrap asc, t1.seqrap asc, decode(t1.seqagrbo,0,t1.seqagrfo,t1.seqagrbo) asc, t1.stanet desc, t1.datrec asc"
  exit $?
fi

if [ "$1" = "-t4" ]
then
  #
  #    Run a test command
  #
  export codgop='C'
  export ficftp=/tmp/theFile.tmp
  export APP_TRI=TVA
  export EVR=DEV
 rwrun60 $TVA_FRM/tvafrapm.rep \
          userid=$STD_ORA_CONNEXION \
          batch=yes \
          desformat="$TVA_FIC/tpefile.prt" \
          desname="$ficftp" \
          destype=file \
          mode=character \
          p_where=" and t1.codgop='$codgop' order by t1.codgop asc, t1.codmne asc, t1.typost asc, t1.ca3isodev asc, t1.typrap asc, t1.seqrap asc, decode(t1.seqagrbo,0,t1.seqagrfo,t1.seqagrbo) asc, t1.stanet desc, t1.datrec asc"

  exit $?
fi

if [ "$1" = "-t5" ]
then
  #
  #    Run a test command (module name withour module=)
  #
  runReportBatch_dev.sh -env $theEnv -server $theServer -user $theUser $debug tpefspfd destype=file mode=CHARACTER paramform=NO desformat=TPEFILE.prt desname=tpefspfd.dat userid=$ORA_CONNEXION P_NUMSEQ=119723 P_DATE_FORM=20060101 P_DATE_TO=20060125 P_CODDMN=SGTOKGLO P_INIOPE="TPE"  P_CA3ISOPAY=JPN P_MNETYPCODTIT=QU P_PTFDET=O P_TYPPOS=F
  exit $?
fi

if [ "$1" = "-t6" ]
then

cmdFile1=`pwd`/cmdFile.cmd

if [ "$USERID" = "" ]
then
  USERID=$ORA_CONNEXION
fi
  runReportBatch_dev.sh -env $theEnv -server $theServer -user $theUser -debug userid=$USERID cmdfile=`pwd`/cmdFile2.cmd
  #runReportBatch_dev.sh -env $theEnv -server $theServer -user $theUser -debug userid=$USERID cmdfile=`pwd`/tpefspfdtokyo_1j.cmd
#  rm -f cmdFile.cmd
  exit $?
fi

if [ "$1" = "-t7" ]
then
echo "\
module=tpefspfd
#userid=/
orientation=LANDSCAPE
destype=file
batch=YES
desformat=tpe23066.prt
mode=CHARACTER
#paramform=NO
p_coddmn=FIXPA
p_ca3isopay=EUR
p_mnetypcodtit=IS
p_ptfdet=Y
p_typpos=F
p_iniop=TPE
p_lsttyptit=A,AABCP,ABAB,ABS,ABSA,ACP,ADR,ANCD,AP,ARGGB,BI,BISF,BMTN,BP,BRADY,BSA,BSAR,BSO,CD,CDO,CI,CIL,CLN,CMO,CORW,COVER,CRH,CW,DEC,DOMZAR,EMTN,EO,EP,ETF,EUROCP,EW,FCC,GDR,HKEFB,JGFB,LANDER,LDC,MBS,MINFIN,O,OBSA,OC,OCBSA,OEA,OI,OO,OPCVM,ORA,PERPBO,PPEMTN,PPEUROCP,PR,PRST,RC,REX,SAGB,SBI,SOV,SPB,TSDI,TSR,TTB
p_numseq=119835
desname=tpefspfdfixpa.out
p_date_form=20070101
p_date_to=20040304
" > cmdFile.cmd

if [ "$USERID" = "" ]
then
  USERID=$ORA_CONNEXION
fi
  runReportBatch_dev.sh -env $theEnv -server $theServer -user $theUser -debug userid=$USERID cmdfile=`pwd`/cmdFile.cmd
#  rm -f cmdFile.cmd
  exit $?
fi

paramCount=0
#
#      To analyze the parameters on the command-line and
# preserve tjheir original values (including blanks),
# we must change the IFS to a character that is NOT in the
# parameters.
#
oldIFS=$IFS
  if [ "`echo $@ | grep @`" = ""  ] ; then  export IFS=@ 
elif [ "`echo $@ | grep �`" = ""  ] ; then  export IFS=� 
elif [ "`echo $@ | grep �`" = ""  ] ; then  export IFS=� 
elif [ "`echo $@ | grep �`" = ""  ] ; then  export IFS=� 
else
  echo "No suitable value found for IFS"
  exit 1
fi
newIFS=$IFS

#
#    Constant representing a quoted double quote (\")
#
#theQuote="@"
theQuote="\\\""

echo "  1) Analysing the command line"
debug "All Params: ['$*']"
pList=""
for param in "$@"
do
  debug "   - Param: [$param]"
  PARAM=`echo $param | tr '[a-z]' '[A-Z]'`
  case $PARAM in
    CMDFILE=*)
      #
      #       Process the command-file, to avoid sub-shell creation
      # in btch and remain compatible with ksh, we must use a for loop.
      #
      #       To allow this for loop to see single lines as a single parameter
      # we must use LINEFEED as field separator.
      #
      theCmdFile=`echo $param | cut -f2 -d=`
        IFS='
'
      for l in $(sed -e "s;\";;g" "$theCmdFile" | grep -v "^#")
      do
#        debug "         - Line: [$l]"
        #
        #    Extract name and value and pass them to the routine
        # processing the command-line
        #
        #   Protect special characters by adding a \ before
        #          $   ==>  \$
        #          (   ==>  \(
        #          )   ==>  \)
        #
        #   NOTE: The sed command below must remain identical to
        # the one in the '*)' case
        #
        pName=`echo $l | cut -f1 -d=`
        pVal=`echo $l | cut -f2-255 -d=   | sed -e 's;\\$;\\\\$;g' \
                                                -e 's;(;\\\\(;g' \
                                                -e 's;);\\\\);g'`
        addParam "$pName" "$pVal"
      done
      IFS=$newIFS
      ;;
    *)
        #
        #    Extract name and value and pass them to the routine
        # processing the command-line
        #
      pName=`echo $param | cut -f1 -d=`
      pVal=`echo $param | cut -f2-255 -d= | sed -e 's;\\$;\\\\$;g' \
                                                -e 's;(;\\\\(;g' \
                                                -e 's;);\\\\);g'`
      addParam "$pName" "$pVal"
      ;;
  esac
done
echo

#
#     Add 10g specific parameters to the command-line
#
#     - temporary file name
#     - report server name
#     - envid name
#
#echo $pList
echo "STD_REPORT_DEST : $STD_REPORT_DEST" 
commandLine="rwclient.sh desname=\$STD_REPORT_DEST/$$.tmp server=\$STD_REPORT_SERVER envid=\${TYPE_ENV}_EN $pList"
#echo $commandLine
debug "=================================================================="
debug "The command line:"
debug "================="
debug "$commandLine"
debug "=================================================================="

realServer=$theServer
echo "  2) Running the report on the server"
echo "     server   : $realServer"
echo "     user     : $theUser"
echo "     env      : $theEnv"

#
#     Run the report an the remote server AFTER positionning the environment
# we execute the users profile just to have the $OUTILS variable positionned.
# can be hardcoded if needed to speed-up execution
#
$SSH $SSH_OPT $realServer -l $theUser "
. \$HOME/.profile >/dev/null 2>&1
export TYPE_ENV=$theEnv
. \$OUTILS/dev_env_std.sh >/dev/null 2>&1
export ORACLE_HOME=/export/oracleias/as10gR2
$commandLine

"
status=$?
echo ""
echo "    Terminated whith status=$status"
echo ""
if [ $status -ne 0 ]
then
  #
  #     If an error occured, we just stop here
  #
  echo "     ERROR: No output generated, aborting the process ...."
  echo
  exit 1
fi

echo "  3) Get value for destination dir on the application server"
#
#     We just run an echo $STD_REPORT_DEST on the remote
# server to know where the temporary file is generated
#
# can be hardcoded if needed to speed-up execution
#

srvDir=`$SSH $SSH_OPT $realServer -l $theUser ". \\$HOME/.profile  >/dev/null ;TYPE_ENV=$theEnv ; . \\$OUTILS/dev_env_std.sh  >/dev/null ; echo \\$STD_REPORT_DEST"`

echo "     dir     : $srvDir"
echo

echo "  4) Transferring the created file"
echo "     Server file : \$STD_REPORT_DEST/$$.tmp"
echo "     Local file  : $theFile"
#
#      Just copy the remote file to the local file
# the -q option avoids the progress indicator of scp.
#
#      If default mode for generated files is 644, the application user can
# be used, otherwithe, we need the oracle User.
#
#scp -q $theUserOracle@$realServer:$srvDir/$$.tmp $theFile
scp -q $theUser@$realServer:$srvDir/$$.tmp $theFile
echo

echo "  6) Removing temporary file from the application server"
#
#     Remove the file on the server, this is optional, if access
# rights don't allow deleting files (sticky bit on the directory)
# the ORACLE user must be used.
#
#ssh $realServer -l $theUserOracle "rm -f $srvDir/$$.tmp"
#$SSH $SSH_OPT $realServer -l $theUser "rm $srvDir/$$.tmp"
echo

