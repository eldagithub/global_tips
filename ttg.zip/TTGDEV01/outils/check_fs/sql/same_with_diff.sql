select a.TTG51_FILE_NAME, 
a.TTG51_FILE_SUM "SUM gataop11", b.TTG51_FILE_SUM "SUM gatdev21", 
a.TTG51_FILE_DATE "DATE gataop11", b.TTG51_FILE_DATE "DATE gatdev21"

from TTG51_CIE a, TTG51_CIE b
where 
a.TTG51_ENV_NAME = 'gataop11' and
b.TTG51_ENV_NAME = 'gatdev21' and  
a.TTG51_FILE_NAME = b.TTG51_FILE_NAME and
a.TTG51_FILE_SUM <> b.TTG51_FILE_SUM 
order by a.TTG51_FILE_NAME

