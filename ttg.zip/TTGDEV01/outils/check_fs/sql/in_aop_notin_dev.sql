select 
b.TTG51_FILE_NAME "IN gataop11 NOT IN gatdev21", 
b.TTG51_FILE_SUM "SUM gataop11", 
b.TTG51_FILE_DATE "DATE gataop11"
from TTG51_CIE b
where
b.TTG51_ENV_NAME = 'gataop11' and  
b.TTG51_FILE_NAME not in 
(
select a.TTG51_FILE_NAME from TTG51_CIE a where
a.TTG51_ENV_NAME = 'gatdev21'   
)

