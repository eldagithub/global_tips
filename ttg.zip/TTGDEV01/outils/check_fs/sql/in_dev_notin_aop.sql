select 
b.TTG51_FILE_NAME "IN gatdev21 NOT IN gataop11", 
b.TTG51_FILE_SUM "SUM gatdev21", 
b.TTG51_FILE_DATE "DATE gatdev21"
from TTG51_CIE b
where
b.TTG51_ENV_NAME = 'gatdev21' and  
b.TTG51_FILE_NAME not in 
(
select a.TTG51_FILE_NAME from TTG51_CIE a where
a.TTG51_ENV_NAME = 'gataop11' 
)
