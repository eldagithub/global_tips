#!/usr/bin/bash
# Script to synchronise from tvaaop11 to tvadev81
# GENERETED AT : 20071204-15h59-29
set -x
DATE_T=$(date '+%Y%m%d-%Hh%M-%S')
TAR_NAME=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev81.tar
TAR_IN_FILE=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev81.$DATE_T.cp
FILE_TO_DEL=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev81.$DATE_T.rm
# LA GENERATION DES COPIES ET DES SUPPRESSIONS
# PARTIE 1 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 ET tvadev81 AVEC DIFFERENCE
echo "

" > ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 2 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 , ABSENTS DANS tvadev81
# #############################################################################
echo "

fic/tva_agorario_rsc.dat                                                                                                
fic/tva_bidev.dat                                                                                                       
fic/tva_clsbf_rsc.dat                                                                                                   
fic/tva_fco_TLN.dat                                                                                                     
fic/tva_fct.dat                                                                                                         
fic/tva_invalid.dat                                                                                                     
fic/tva_lst_cpn_mod.dat                                                                                                 
fic/tva_lst_nonval.dat                                                                                                  
fic/tva_lst_nonvld.dat                                                                                                  
fic/tva_lst_nonvld_day.dat                                                                                              
fic/tva_lst_nonvld_eqt.dat                                                                                              
fic/tva_lst_nonvld_eqt_def.dat                                                                                          
fic/tva_ltverfra_rsc.dat                                                                                                
fic/tva_res.dat                                                                                                         
fic/tva_resv1.dat                                                                                                       
fic/tva_secthb_rsc.dat                                                                                                  
fic/tva_socsocor_rsc.dat                                                                                                
src/addjo.c                                                                                                             
src/addjo.pc                                                                                                            
src/gat_fmt_retswi.c                                                                                                    
src/ges_tostraptva.c                                                                                                    
src/ges_tostraptva.h                                                                                                    
src/ges_tostraptva.pc                                                                                                   
src/ges_tqtdostraptva.c                                                                                                 
src/ges_tqtdostraptva.h                                                                                                 
src/ges_tqtdostraptva.pc                                                                                                
src/make_tva                                                                                                            
src/make_tva.depend                                                                                                     
src/make_tva_crosby                                                                                                     
src/std_spool.c                                                                                                         
src/tpe_atl_define.h                                                                                                    
src/tpe_atl_procedure.h                                                                                                 
src/tpe_cre_ann_stl.h                                                                                                   
src/tpe_define.h                                                                                                        
src/tpe_ext_atlas.c                                                                                                     
src/tpe_fct_global.h                                                                                                    
src/tpe_fct_lib.h                                                                                                       
src/tpe_fct_util.h                                                                                                      
src/tpe_lib_ora_atlas.c                                                                                                 
src/tpe_lib_ora_atlas.pc                                                                                                
src/tpe_trax.c                                                                                                          
src/tpe_trax.h                                                                                                          
src/tpe_util.h                                                                                                          
src/tva_calrep.c                                                                                                        
src/tva_calrep.pc                                                                                                       
src/tva_cnf_define.h                                                                                                    
src/tva_cnf_env_new.c                                                                                                   
src/tva_cnf_gen.c                                                                                                       
src/tva_cnf_gen_swi.c                                                                                                   
src/tva_cnf_global.h                                                                                                    
src/tva_cnf_ret_new.c                                                                                                   
src/tva_cnf_struct.h                                                                                                    
src/tva_cre_ann_stl.c                                                                                                   
src/tva_cre_ann_stl.h                                                                                                   
src/tva_cre_convert.c                                                                                                   
src/tva_cre_eprec.c                                                                                                     
src/tva_cre_eprec.pc                                                                                                    
src/tva_cre_eprec_asi.c                                                                                                 
src/tva_cre_mns.h                                                                                                       
src/tva_cre_mns_asi.h                                                                                                   
src/tva_cre_rcl.c                                                                                                       
src/tva_cre_rcl.pc                                                                                                      
src/tva_cre_war_hb.c                                                                                                    
src/tva_cre_war_hb.pc                                                                                                   
src/tva_define.h                                                                                                        
src/tva_edi_cre_war1.c                                                                                                  
src/tva_edi_cre_war1.pc                                                                                                 
src/tva_edi_cre_war2.c                                                                                                  
src/tva_edi_cre_war2.pc                                                                                                 
src/tva_edition.c                                                                                                       
src/tva_edition.h                                                                                                       
src/tva_fct.c                                                                                                           
src/tva_fct_dblib.h                                                                                                     
src/tva_fct_global.h                                                                                                    
src/tva_fct_lib.h                                                                                                       
src/tva_fct_util.h                                                                                                      
src/tva_fmt_agr_gen.c                                                                                                   
src/tva_fmt_bppbmil.c                                                                                                   
src/tva_fmt_chrisosl.c                                                                                                  
src/tva_fmt_clsbf.c                                                                                                     
src/tva_fmt_clsbfm.c                                                                                                    
src/tva_fmt_cowen.c                                                                                                     
src/tva_fmt_ddbk.c                                                                                                      
src/tva_fmt_edm.c                                                                                                       
src/tva_fmt_eurex.c                                                                                                     
src/tva_fmt_fimsgp.c                                                                                                    
src/tva_fmt_fincolis.c                                                                                                  
src/tva_fmt_helexfin.c                                                                                                  
src/tva_fmt_ltverfra.c                                                                                                  
src/tva_fmt_nordbk.c                                                                                                    
src/tva_fmt_parelr.c                                                                                                    
src/tva_fmt_sgarbpar.c                                                                                                  
src/tva_fmt_sgsnp.c                                                                                                     
src/tva_fmt_sgst.c                                                                                                      
src/tva_fmt_sgzu.c                                                                                                      
src/tva_global.h                                                                                                        
src/tva_jououv.c                                                                                                        
src/tva_jououv.pc                                                                                                       
src/tva_module.h                                                                                                        
src/tva_rec.c                                                                                                           
src/tva_rec_cowen.c                                                                                                     
src/tva_rec_crosby.c                                                                                                    
src/tva_rec_extract.c                                                                                                   
src/tva_rec_gus.c                                                                                                       
src/tva_ret_ann_stl.c                                                                                                   
src/tva_rwa_bsy_convert.c                                                                                               
src/tva_stajou.c                                                                                                        
src/tva_stajou.pc                                                                                                       
src/tva_struct.h                                                                                                        
src/tva_traab_gen_fco.c                                                                                                 
src/tva_traab_gen_fco.h                                                                                                 
src/tva_traab_gen_fct.c                                                                                                 
src/tva_traab_gen_fct.h                                                                                                 
src/tva_uti.c                                                                                                           
src/tva_uti.pc                                                                                                          
src/tva_util.h                                                                                                          
src/tva_vld_crs_bck.c                                                                                                   
src/tva_vld_crs_bck.h                                                                                                   
src/tvaostrap.c                                                                                                         
src/tvaostrap.pc                                                                                                        
src/tvaostraptva.h                                                                                                      
src/tvarepclsbf.c                                                                                                       
" >> ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 3 SUPPRESSIONS : LISTE DES FICHERS PRESENTS DANS tvadev81 , ABSENTS DANS tvaaop11
# #############################################################################
echo "

" > $FILE_TO_DEL



# DEBUT DES LANCEMENT DE SYNC
cd /home/ttgdev01/.AOP/REFERENCE/tvaaop11
cat ${TAR_IN_FILE}0|sed 's/^.\///g' > ${TAR_IN_FILE}1
cat ${TAR_IN_FILE}1|sed 's/^$//g' > ${TAR_IN_FILE}0
cat ${TAR_IN_FILE}0|sed 's/ //g' > ${TAR_IN_FILE}
/usr/bin/tar cvf $TAR_NAME -I ${TAR_IN_FILE}
STEP1_COMMAND="tar xf $TAR_NAME"
echo "ssh tvadev81@tvadevap80 $STEP1_COMMAND "
 ssh -v tvadev81@tvadevap80 $STEP1_COMMAND 
STEP2_COMMAND="ksh $FILE_TO_DEL"
echo $STEP2_COMMAND
echo " ssh tvadev81@tvadevap80 $STEP2_COMMAND "
 ssh -v tvadev81@tvadevap80 $STEP2_COMMAND 
# rm ${TAR_IN_FILE}0 ${TAR_IN_FILE}1 ${TAR_IN_FILE} 
