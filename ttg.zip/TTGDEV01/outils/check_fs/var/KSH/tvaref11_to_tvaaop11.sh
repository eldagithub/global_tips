#!/usr/bin/bash
# Script to synchronise from tvaref11 to tvaaop11
# GENERETED AT : 20080609-08h04-33
set -x
DATE_T=$(date '+%Y%m%d-%Hh%M-%S')
TAR_NAME=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaref11_to_tvaaop11.tar
TAR_IN_FILE=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaref11_to_tvaaop11.$DATE_T.cp
FILE_TO_DEL=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaref11_to_tvaaop11.$DATE_T.rm
# LA GENERATION DES COPIES ET DES SUPPRESSIONS
# PARTIE 1 COPIE : LISTE DES FICHERS PRESENTS DANS tvaref11 ET tvaaop11 AVEC DIFFERENCE
echo "

par/tit_bzf.csv                                                                                                         
tvaprd11_tar_date                                                                                                       

" > ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 2 COPIE : LISTE DES FICHERS PRESENTS DANS tvaref11 , ABSENTS DANS tvaaop11
# #############################################################################
echo "
" >> ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 3 SUPPRESSIONS : LISTE DES FICHERS PRESENTS DANS tvaaop11 , ABSENTS DANS tvaref11
# #############################################################################
echo "
" > $FILE_TO_DEL



# DEBUT DES LANCEMENT DE SYNC
cd /home/ttgdev01/.AOP/REFERENCE/tvaref11
cat ${TAR_IN_FILE}0|sed 's/^.\///g' > ${TAR_IN_FILE}1
cat ${TAR_IN_FILE}1|sed 's/^$//g' > ${TAR_IN_FILE}0
cat ${TAR_IN_FILE}0|sed 's/ //g' > ${TAR_IN_FILE}
/usr/bin/tar cvf $TAR_NAME -I ${TAR_IN_FILE}
STEP1_COMMAND="tar xf $TAR_NAME"
echo "ssh tvaaop11@ttgdevap10 $STEP1_COMMAND "
# ssh -v tvaaop11@ttgdevap10 $STEP1_COMMAND 
STEP2_COMMAND="ksh $FILE_TO_DEL"
echo $STEP2_COMMAND
echo " ssh tvaaop11@ttgdevap10 $STEP2_COMMAND "
# ssh -v tvaaop11@ttgdevap10 $STEP2_COMMAND 
# rm ${TAR_IN_FILE}0 ${TAR_IN_FILE}1 ${TAR_IN_FILE} 
