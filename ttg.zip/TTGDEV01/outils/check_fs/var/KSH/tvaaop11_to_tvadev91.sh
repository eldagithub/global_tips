#!/usr/bin/bash
# Script to synchronise from tvaaop11 to tvadev91
# GENERETED AT : 20071204-17h14-36
set -x
DATE_T=$(date '+%Y%m%d-%Hh%M-%S')
TAR_NAME=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev91.tar
TAR_IN_FILE=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev91.$DATE_T.cp
FILE_TO_DEL=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev91.$DATE_T.rm
# LA GENERATION DES COPIES ET DES SUPPRESSIONS
# PARTIE 1 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 ET tvadev91 AVEC DIFFERENCE
echo "


" > ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 2 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 , ABSENTS DANS tvadev91
# #############################################################################
echo "

fic/tva_agorario_rsc.dat                                                                                                
fic/tva_bidev.dat                                                                                                       
fic/tva_clsbf_rsc.dat                                                                                                   
fic/tva_fco_TLN.dat                                                                                                     
fic/tva_fct.dat                                                                                                         
fic/tva_invalid.dat                                                                                                     
fic/tva_lst_cpn_mod.dat                                                                                                 
fic/tva_lst_nonval.dat                                                                                                  
fic/tva_lst_nonvld.dat                                                                                                  
fic/tva_lst_nonvld_day.dat                                                                                              
fic/tva_lst_nonvld_eqt.dat                                                                                              
fic/tva_lst_nonvld_eqt_def.dat                                                                                          
fic/tva_ltverfra_rsc.dat                                                                                                
fic/tva_res.dat                                                                                                         
fic/tva_resv1.dat                                                                                                       
fic/tva_secthb_rsc.dat                                                                                                  
fic/tva_socsocor_rsc.dat                                                                                                
" >> ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 3 SUPPRESSIONS : LISTE DES FICHERS PRESENTS DANS tvadev91 , ABSENTS DANS tvaaop11
# #############################################################################
echo "

" > $FILE_TO_DEL



# DEBUT DES LANCEMENT DE SYNC
cd /home/ttgdev01/.AOP/REFERENCE/tvaaop11
cat ${TAR_IN_FILE}0|sed 's/^.\///g' > ${TAR_IN_FILE}1
cat ${TAR_IN_FILE}1|sed 's/^$//g' > ${TAR_IN_FILE}0
cat ${TAR_IN_FILE}0|sed 's/ //g' > ${TAR_IN_FILE}
/usr/bin/tar cvf $TAR_NAME -I ${TAR_IN_FILE}
STEP1_COMMAND="tar xf $TAR_NAME"
echo "ssh tvadev91@tvadevap90 $STEP1_COMMAND "
 ssh -v tvadev91@tvadevap90 $STEP1_COMMAND 
STEP2_COMMAND="ksh $FILE_TO_DEL"
echo $STEP2_COMMAND
echo " ssh tvadev91@tvadevap90 $STEP2_COMMAND "
 ssh -v tvadev91@tvadevap90 $STEP2_COMMAND 
# rm ${TAR_IN_FILE}0 ${TAR_IN_FILE}1 ${TAR_IN_FILE} 
