#!/usr/bin/bash
# Script to synchronise from tvaaop11 to tvadev32
# GENERETED AT : 20071204-17h33-51
set -x
DATE_T=$(date '+%Y%m%d-%Hh%M-%S')
TAR_NAME=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev32.tar
TAR_IN_FILE=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev32.$DATE_T.cp
FILE_TO_DEL=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev32.$DATE_T.rm
# LA GENERATION DES COPIES ET DES SUPPRESSIONS
# PARTIE 1 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 ET tvadev32 AVEC DIFFERENCE
echo "

exe/std_spool.e                                                                                                         
exe/tpe_ext_atlas.e                                                                                                     
exe/tpe_sav_edm.e                                                                                                       
exe/tpe_trax.e                                                                                                          
exe/tva_cnf_env_new.e                                                                                                   
exe/tva_cnf_gen.e                                                                                                       
exe/tva_cnf_gen_swi.e                                                                                                   
exe/tva_cnf_ret_new.e                                                                                                   
exe/tva_cre_ann_stl.e                                                                                                   
exe/tva_cre_convert.e                                                                                                   
exe/tva_cre_eprec.e                                                                                                     
exe/tva_cre_rcl.e                                                                                                       
exe/tva_cre_war_hb.e                                                                                                    
exe/tva_edi_cre_war1.e                                                                                                  
exe/tva_edi_cre_war2.e                                                                                                  
exe/tva_fmt_agr_gen.e                                                                                                   
exe/tva_fmt_bppbmil.e                                                                                                   
exe/tva_fmt_chrisosl.e                                                                                                  
exe/tva_fmt_clsbf.e                                                                                                     
exe/tva_fmt_clsbfm.e                                                                                                    
exe/tva_fmt_cowen.e                                                                                                     
exe/tva_fmt_ddbk.e                                                                                                      
exe/tva_fmt_edm.e                                                                                                       
exe/tva_fmt_eurex.e                                                                                                     
exe/tva_fmt_fimsgp.e                                                                                                    
exe/tva_fmt_fincolis.e                                                                                                  
exe/tva_fmt_helexfin.e                                                                                                  
exe/tva_fmt_ltverfra.e                                                                                                  
exe/tva_fmt_nordbk.e                                                                                                    
exe/tva_fmt_parelr.e                                                                                                    
exe/tva_fmt_sgarbpar.e                                                                                                  
exe/tva_fmt_sgsnp.e                                                                                                     
exe/tva_fmt_sgst.e                                                                                                      
exe/tva_fmt_sgzu.e                                                                                                      
exe/tva_jououv.e                                                                                                        
exe/tva_rec.e                                                                                                           
exe/tva_rec_gus.e                                                                                                       
exe/tva_ret_ann_stl.e                                                                                                   
exe/tva_rwa_bsy_convert.e                                                                                               
exe/tva_traab_gen_fco.e                                                                                                 
exe/tva_traab_gen_fct.e                                                                                                 
exe/tva_vld_crs_bck.e                                                                                                   
exe/tvaostrap.e                                                                                                         
exe/tvarepclsbf.e                                                                                                       
obj/addjo.o                                                                                                             
obj/ges_tostraptva.o                                                                                                    
obj/ges_tqtdostraptva.o                                                                                                 
obj/libtva.a                                                                                                            
obj/std_spool.o                                                                                                         
obj/tpe_ext_atlas.o                                                                                                     
obj/tpe_lib_ora_atlas.o                                                                                                 
obj/tpe_sav_edm.o                                                                                                       
obj/tpe_trax.o                                                                                                          
obj/tva_calrep.o                                                                                                        
obj/tva_cnf_env_new.o                                                                                                   
obj/tva_cnf_gen.o                                                                                                       
obj/tva_cnf_gen_swi.o                                                                                                   
obj/tva_cnf_ret_new.o                                                                                                   
obj/tva_cre_ann_stl.o                                                                                                   
obj/tva_cre_convert.o                                                                                                   
obj/tva_cre_eprec.o                                                                                                     
obj/tva_cre_rcl.o                                                                                                       
obj/tva_cre_war_hb.o                                                                                                    
obj/tva_edi_cre_war1.o                                                                                                  
obj/tva_edi_cre_war2.o                                                                                                  
obj/tva_edition.o                                                                                                       
obj/tva_fct.o                                                                                                           
obj/tva_fmt_agr_gen.o                                                                                                   
obj/tva_fmt_bppbmil.o                                                                                                   
obj/tva_fmt_chrisosl.o                                                                                                  
obj/tva_fmt_clsbf.o                                                                                                     
obj/tva_fmt_clsbfm.o                                                                                                    
obj/tva_fmt_cowen.o                                                                                                     
obj/tva_fmt_ddbk.o                                                                                                      
obj/tva_fmt_edm.o                                                                                                       
obj/tva_fmt_eurex.o                                                                                                     
obj/tva_fmt_fimsgp.o                                                                                                    
obj/tva_fmt_fincolis.o                                                                                                  
obj/tva_fmt_helexfin.o                                                                                                  
obj/tva_fmt_ltverfra.o                                                                                                  
obj/tva_fmt_nordbk.o                                                                                                    
obj/tva_fmt_parelr.o                                                                                                    
obj/tva_fmt_sgarbpar.o                                                                                                  
obj/tva_fmt_sgsnp.o                                                                                                     
obj/tva_fmt_sgst.o                                                                                                      
obj/tva_fmt_sgzu.o                                                                                                      
obj/tva_jououv.o                                                                                                        
obj/tva_rec.o                                                                                                           
obj/tva_rec_gus.o                                                                                                       
obj/tva_ret_ann_stl.o                                                                                                   
obj/tva_rwa_bsy_convert.o                                                                                               
obj/tva_stajou.o                                                                                                        
obj/tva_traab_gen_fco.o                                                                                                 
obj/tva_traab_gen_fct.o                                                                                                 
obj/tva_uti.o                                                                                                           
obj/tva_vld_crs_bck.o                                                                                                   
obj/tvaostrap.o                                                                                                         
obj/tvarepclsbf.o                                                                                                       
par/l_his_stk_tva_spool3.par                                                                                            
par/tit_bzf.csv                                                                                                         
par/tva_glo_vld_B.par                                                                                                   
par/tva_glo_vld_C.par                                                                                                   
par/tva_glo_vld_I.par                                                                                                   
src/addjo.c                                                                                                             
src/ges_tostraptva.c                                                                                                    
src/ges_tqtdostraptva.c                                                                                                 
src/make_tva                                                                                                            
src/tpe_lib_ora_atlas.c                                                                                                 
src/tva_calrep.c                                                                                                        
src/tva_cre_ann_stl.c                                                                                                   
src/tva_cre_eprec.c                                                                                                     
src/tva_cre_eprec.pc                                                                                                    
src/tva_cre_rcl.c                                                                                                       
src/tva_cre_war_hb.c                                                                                                    
src/tva_edi_cre_war1.c                                                                                                  
src/tva_edi_cre_war2.c                                                                                                  
src/tva_jououv.c                                                                                                        
src/tva_stajou.c                                                                                                        
src/tva_uti.c                                                                                                           
src/tva_vld_crs_bck.c                                                                                                   
src/tvaostrap.c                                                                                                         
src/tvaostrap.pc                                                                                                        
srv/mrp/meta/tva_mrp_database_connect.prop                                                                              
uti/recompil.sql                                                                                                        

" > ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 2 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 , ABSENTS DANS tvadev32
# #############################################################################
echo "

exe/gat_fmt_retswi.e                                                                                                    
fic/tva_agorario_rsc.dat                                                                                                
fic/tva_bidev.dat                                                                                                       
fic/tva_clsbf_rsc.dat                                                                                                   
fic/tva_fco_TLN.dat                                                                                                     
fic/tva_fct.dat                                                                                                         
fic/tva_invalid.dat                                                                                                     
fic/tva_lst_cpn_mod.dat                                                                                                 
fic/tva_lst_nonval.dat                                                                                                  
fic/tva_lst_nonvld.dat                                                                                                  
fic/tva_lst_nonvld_day.dat                                                                                              
fic/tva_ltverfra_rsc.dat                                                                                                
fic/tva_res.dat                                                                                                         
fic/tva_resv1.dat                                                                                                       
fic/tva_secthb_rsc.dat                                                                                                  
fic/tva_socsocor_rsc.dat                                                                                                
obj/gat_fmt_retswi.o                                                                                                    
src/make_tva_crosby                                                                                                     
" >> ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 3 SUPPRESSIONS : LISTE DES FICHERS PRESENTS DANS tvadev32 , ABSENTS DANS tvaaop11
# #############################################################################
echo "

rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/gat_fmt_retswi.e                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/std_cvdate                                                     
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/std_etabatch.sql                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/std_spool.e                                                    
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tpe_ext_atlas.e                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tpe_sav_edm.e                                                  
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tpe_trax.e                                                     
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cnf_env_new.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cnf_env_new.e.130307                                       
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cnf_gen.e                                                  
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cnf_gen.e.20060912                                         
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cnf_gen_swi.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cnf_ret_new.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_ann_stl.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_convert.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_convert_asi.e                                          
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_eprec.e                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_eprec.e.20070421                                       
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_rcl.e                                                  
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_war_hb.e                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_cre_war_hb.e.20070421                                      
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_edi_cre_war1.e                                             
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_edi_cre_war2.e                                             
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_agr_gen.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_bppbmil.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_chrisosl.e                                             
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_clsbf.e                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_clsbfm.e                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_cowen.e                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_ddbk.e                                                 
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_edm.e                                                  
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_eurex.e                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_fimsgp.e                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_fincolis.e                                             
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_helexfin.e                                             
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_ltverfra.e                                             
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_nordbk.e                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_parelr.e                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_sgarbpar.e                                             
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_sgsnp.e                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_sgst.e                                                 
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_fmt_sgzu.e                                                 
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_jououv.e                                                   
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_rec.e                                                      
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_rec_extract.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_rec_gus.e                                                  
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_ret_ann_stl.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_rwa_bsy_convert.e                                          
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_traab_gen_fco.e                                            
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_traab_gen_fct.e                                            
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tva_vld_crs_bck.e                                              
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tvaostrap.e                                                    
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/exe/backup/tvarepclsbf.e                                                  
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/par/z10_param.tmp                                                         
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/sql/prg_cpt_mns.sql                                                       
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/sql/sav_cpt_mns.sql                                                       
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/sql/sav_cpt_mns_2.sql                                                     
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/Tva_cre_eorec.pc                                                      
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/gat_fmt_retswi_fonct.c                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/gat_fmt_retswi_fonct.h                                                
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/gat_fmt_retswi_global.h                                               
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/gat_fmt_retswi_spec.c                                                 
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/gat_fmt_retswi_spec.h                                                 
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/gat_sys_fonct.c                                                       
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/gat_sys_fonct.h                                                       
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/tpe_sav_edm.c                                                         
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/src/tva_cre_eprec.pc.bak                                                  
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/srv/mrp/meta/jmx.prop                                                     
rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev32/srv/mrp/meta/jmxremote.password                                           
" > $FILE_TO_DEL



# DEBUT DES LANCEMENT DE SYNC
cd /home/ttgdev01/.AOP/REFERENCE/tvaaop11
cat ${TAR_IN_FILE}0|sed 's/^.\///g' > ${TAR_IN_FILE}1
cat ${TAR_IN_FILE}1|sed 's/^$//g' > ${TAR_IN_FILE}0
cat ${TAR_IN_FILE}0|sed 's/ //g' > ${TAR_IN_FILE}
/usr/bin/tar cvf $TAR_NAME -I ${TAR_IN_FILE}
STEP1_COMMAND="tar xf $TAR_NAME"
echo "ssh tvadev32@tvadevap30 $STEP1_COMMAND "
# ssh -v tvadev32@tvadevap30 $STEP1_COMMAND 
STEP2_COMMAND="ksh $FILE_TO_DEL"
echo $STEP2_COMMAND
echo " ssh tvadev32@tvadevap30 $STEP2_COMMAND "
# ssh -v tvadev32@tvadevap30 $STEP2_COMMAND 
# rm ${TAR_IN_FILE}0 ${TAR_IN_FILE}1 ${TAR_IN_FILE} 
