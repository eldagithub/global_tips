#!/usr/bin/bash
# Script to synchronise from tperef19 to tpeaop19
# GENERETED AT : 20080609-08h17-59
set -x
DATE_T=$(date '+%Y%m%d-%Hh%M-%S')
TAR_NAME=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tperef19_to_tpeaop19.tar
TAR_IN_FILE=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tperef19_to_tpeaop19.$DATE_T.cp
FILE_TO_DEL=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tperef19_to_tpeaop19.$DATE_T.rm
# LA GENERATION DES COPIES ET DES SUPPRESSIONS
# PARTIE 1 COPIE : LISTE DES FICHERS PRESENTS DANS tperef19 ET tpeaop19 AVEC DIFFERENCE
echo "

jboss4/jboss-4.0.3/bin/XTNcheck.html                                                                                    
jboss4/jboss-4.0.3/bin/claim_bill.doc                                                                                   
jboss4/jboss-4.0.3/bin/claim_dividend.doc                                                                               
jboss4/jboss-4.0.3/server/dvd/data/hypersonic/localDB.backup                                                            
jboss4/jboss-4.0.3/server/dvd/data/hypersonic/localDB.lck                                                               
jboss4/jboss-4.0.3/server/dvd/data/hypersonic/localDB.properties                                                        
jboss4/jboss-4.0.3/server/dvd/data/hypersonic/localDB.script                                                            

" > ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 2 COPIE : LISTE DES FICHERS PRESENTS DANS tperef19 , ABSENTS DANS tpeaop19
# #############################################################################
echo "

tpeprd19_tar_date                                                                                                       
" >> ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 3 SUPPRESSIONS : LISTE DES FICHERS PRESENTS DANS tpeaop19 , ABSENTS DANS tperef19
# #############################################################################
echo "
" > $FILE_TO_DEL



# DEBUT DES LANCEMENT DE SYNC
cd /home/ttgdev01/.AOP/REFERENCE/tperef19
cat ${TAR_IN_FILE}0|sed 's/^.\///g' > ${TAR_IN_FILE}1
cat ${TAR_IN_FILE}1|sed 's/^$//g' > ${TAR_IN_FILE}0
cat ${TAR_IN_FILE}0|sed 's/ //g' > ${TAR_IN_FILE}
/usr/bin/tar cvf $TAR_NAME -I ${TAR_IN_FILE}
STEP1_COMMAND="tar xf $TAR_NAME"
echo "ssh tpeaop19@ttgdevap10 $STEP1_COMMAND "
# ssh -v tpeaop19@ttgdevap10 $STEP1_COMMAND 
STEP2_COMMAND="ksh $FILE_TO_DEL"
echo $STEP2_COMMAND
echo " ssh tpeaop19@ttgdevap10 $STEP2_COMMAND "
# ssh -v tpeaop19@ttgdevap10 $STEP2_COMMAND 
# rm ${TAR_IN_FILE}0 ${TAR_IN_FILE}1 ${TAR_IN_FILE} 
