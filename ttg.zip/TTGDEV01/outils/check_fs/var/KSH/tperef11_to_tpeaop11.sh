#!/usr/bin/bash
# Script to synchronise from tperef11 to tpeaop11
# GENERETED AT : 20080609-08h14-12
set -x
DATE_T=$(date '+%Y%m%d-%Hh%M-%S')
TAR_NAME=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tperef11_to_tpeaop11.tar
TAR_IN_FILE=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tperef11_to_tpeaop11.$DATE_T.cp
FILE_TO_DEL=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tperef11_to_tpeaop11.$DATE_T.rm
# LA GENERATION DES COPIES ET DES SUPPRESSIONS
# PARTIE 1 COPIE : LISTE DES FICHERS PRESENTS DANS tperef11 ET tpeaop11 AVEC DIFFERENCE
echo "

tpeprd11_tar_date                                                                                                       

" > ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 2 COPIE : LISTE DES FICHERS PRESENTS DANS tperef11 , ABSENTS DANS tpeaop11
# #############################################################################
echo "

java/build/rlconf/Lanceur$1.class                                                                                       
java/build/rlconf/Lanceur$Attente.class                                                                                 
java/build/utility/ConnectionPool$PooledConnection.class                                                                
" >> ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 3 SUPPRESSIONS : LISTE DES FICHERS PRESENTS DANS tpeaop11 , ABSENTS DANS tperef11
# #############################################################################
echo "
" > $FILE_TO_DEL



# DEBUT DES LANCEMENT DE SYNC
cd /home/ttgdev01/.AOP/REFERENCE/tperef11
cat ${TAR_IN_FILE}0|sed 's/^.\///g' > ${TAR_IN_FILE}1
cat ${TAR_IN_FILE}1|sed 's/^$//g' > ${TAR_IN_FILE}0
cat ${TAR_IN_FILE}0|sed 's/ //g' > ${TAR_IN_FILE}
/usr/bin/tar cvf $TAR_NAME -I ${TAR_IN_FILE}
STEP1_COMMAND="tar xf $TAR_NAME"
echo "ssh tpeaop11@ttgdevap10 $STEP1_COMMAND "
# ssh -v tpeaop11@ttgdevap10 $STEP1_COMMAND 
STEP2_COMMAND="ksh $FILE_TO_DEL"
echo $STEP2_COMMAND
echo " ssh tpeaop11@ttgdevap10 $STEP2_COMMAND "
# ssh -v tpeaop11@ttgdevap10 $STEP2_COMMAND 
# rm ${TAR_IN_FILE}0 ${TAR_IN_FILE}1 ${TAR_IN_FILE} 
