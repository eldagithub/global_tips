#!/usr/bin/bash
# Script to synchronise from tvaaop11 to tvadev22
# GENERETED AT : 20071204-16h09-57
set -x
DATE_T=$(date '+%Y%m%d-%Hh%M-%S')
TAR_NAME=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev22.tar
TAR_IN_FILE=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev22.$DATE_T.cp
FILE_TO_DEL=/home/ttgdev01/aop/outils/check_fs//work//SYNC/tvaaop11_to_tvadev22.$DATE_T.rm
# LA GENERATION DES COPIES ET DES SUPPRESSIONS
# PARTIE 1 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 ET tvadev22 AVEC DIFFERENCE
echo "

par/tit_bzf.csv                                                                                                         
par/tva_glo_vld_B.par                                                                                                   
par/tva_glo_vld_C.par                                                                                                   
par/tva_glo_vld_I.par                                                                                                   
srv/mrp/meta/tva_mrp_database_connect.prop                                                                              

" > ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 2 COPIE : LISTE DES FICHERS PRESENTS DANS tvaaop11 , ABSENTS DANS tvadev22
# #############################################################################
echo "
" >> ${TAR_IN_FILE}0

# #############################################################################
# PARTIE 3 SUPPRESSIONS : LISTE DES FICHERS PRESENTS DANS tvadev22 , ABSENTS DANS tvaaop11
# #############################################################################
echo "

rm -rf /home/ttgdev01/.AOP/REFERENCE/tvadev22/par/z10_param.tmp                                                         
" > $FILE_TO_DEL



# DEBUT DES LANCEMENT DE SYNC
cd /home/ttgdev01/.AOP/REFERENCE/tvaaop11
cat ${TAR_IN_FILE}0|sed 's/^.\///g' > ${TAR_IN_FILE}1
cat ${TAR_IN_FILE}1|sed 's/^$//g' > ${TAR_IN_FILE}0
cat ${TAR_IN_FILE}0|sed 's/ //g' > ${TAR_IN_FILE}
/usr/bin/tar cvf $TAR_NAME -I ${TAR_IN_FILE}
STEP1_COMMAND="tar xf $TAR_NAME"
echo "ssh tvadev22@tvadevap20 $STEP1_COMMAND "
# ssh -v tvadev22@tvadevap20 $STEP1_COMMAND 
STEP2_COMMAND="ksh $FILE_TO_DEL"
echo $STEP2_COMMAND
echo " ssh tvadev22@tvadevap20 $STEP2_COMMAND "
# ssh -v tvadev22@tvadevap20 $STEP2_COMMAND 
# rm ${TAR_IN_FILE}0 ${TAR_IN_FILE}1 ${TAR_IN_FILE} 
