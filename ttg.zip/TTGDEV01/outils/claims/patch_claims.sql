set echo on
set time on
set timing on

spool ./patch_claims.log

UPDATE TCCTFAXTPE SET ADRMBX='TO_BEDEFINED@sgcib.com'

spool off

