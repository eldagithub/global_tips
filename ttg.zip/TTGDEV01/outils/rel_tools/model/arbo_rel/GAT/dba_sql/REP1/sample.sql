select *  from dual;
