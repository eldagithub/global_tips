spool REP1.log
set echo off;
set heading off;
set FEEDBACK off;

prompt Liste of invalid objects
prompt ________________________

select owner || ' - ' || object_type || ' : ' || count(*) from dba_objects where status!='VALID'
group by owner,object_type;


prompt
prompt ___________________________________________
prompt
prompt Should be on OPS$TVAEXPLO@OPARTVAX01

select 'You are on the database :' || global_name ||  ', whith the user :'  from global_name;
show user;

prompt ___________________________________________

prompt Press any key to Continue or Control-c to STOP
accept "Pause"




set heading on;
set FEEDBACK on; 
set timing on;
set time on;
set echo on;

-- insert your scripts here : 
-- BEGIN

@./REP1/sample.sql

-- END
spool off;

